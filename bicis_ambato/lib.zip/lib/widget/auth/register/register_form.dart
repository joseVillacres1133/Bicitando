import 'package:bicis_ambato/widget/pswd_text_field.dart';
import 'package:flutter/material.dart';

import 'package:bicis_ambato/widget/text_field.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';

import '../../../blocs/auth/register/bloc.dart';
import '../../../data/models/user.dart';
import '../../../style/style.dart';
import '../../../utils/constants_msg.dart';
import '../../../utils/sharedprefs_helper.dart';

class RegisterForm extends StatefulWidget {
  const RegisterForm({super.key});

  @override
  State<RegisterForm> createState() => _RegisterFormState();
}

class _RegisterFormState extends State<RegisterForm> {
  final TextEditingController _cedulaController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _direccionController = TextEditingController();
  final TextEditingController _telefonoController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool? passwordVisible;
  bool? passwordVisibleConfir;
  bool _isChecked = false;

  late RegisterBloc _registerBloc;
  final Prefs _prefs = Prefs();

  bool get isPopulated =>
      _emailController.text.isNotEmpty &&
      _nameController.text.isNotEmpty &&
      _passwordController.text.isNotEmpty &&
      _confirmPasswordController.text.isNotEmpty &&
      _isChecked;

  bool isRegisterButtonEnabled(RegisterState state) {
    return state.isFormValid && isPopulated;
  }

  @override
  void initState() {
    super.initState();
    _registerBloc = BlocProvider.of<RegisterBloc>(context);

    //Listeners
    _cedulaController.addListener(_onCedulaChanged);
    _nameController.addListener(_onNameChanged);
    _emailController.addListener(_onEmailChanged);
    _direccionController.addListener(_onDireccionChanged);
    _telefonoController.addListener(_onPhoneChanged);
    _passwordController.addListener(_onPasswordChanged);
    _confirmPasswordController.addListener(_onConfirmPasswordChanged);

    // _nameController.text = 'Andres Villacres';
    // _emailController.text = 'andres@ambatobike.ec';
    // _passwordController.text = '1234';
    // _confirmPasswordController.text = '1234';

    passwordVisible = true;
    passwordVisibleConfir = true;
  }

  void showWarning(BuildContext context) {
    final dialog = AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      backgroundColor: secondary,
      content: const ListTile(
        title: Text(
          str_need_add_permissions,
          // style: poppinsBold(
          //     ScreenUtil().setSp(
          //       4,
          //     ),
          //     Colors.white),
        ),
        subtitle: Text(
          str_can_permission_phone,
          // style: poppinsRegular(
          //     ScreenUtil().setSp(
          //       4,
          //     ),
          //     Colors.white),
        ),
      ),
    );
    showDialog(
        context: context, barrierDismissible: false, builder: (x) => dialog);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        Navigator.pushReplacementNamed(context, 'login');
      },
      child: BlocListener(
        bloc: _registerBloc,
        listener: (BuildContext context, RegisterState state) async {
          if (state.isSubmitting!) {
            ScaffoldMessenger.of(context)
              ..hideCurrentSnackBar()
              ..showSnackBar(const SnackBar(
                backgroundColor: purplelight,
                content: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      str_process,
                    ),
                    CircularProgressIndicator(
                      color: yellow,
                    ),
                  ],
                ),
              ));

            if (state.isFailure!) {
              FlutterWindowManager.clearFlags(
                  FlutterWindowManager.FLAG_NOT_TOUCHABLE);
              print("form failed");
            }
          }
          if (state.isSuccess!) {
            //await updateCedulaApiResult(_prefs.idUserPartner);
            //await saveToken();
            _prefs.email = "A";
            showDialog(
                context: context,
                builder: (context) {
                  Future.delayed(const Duration(seconds: 3), () {
                    Navigator.pushReplacementNamed(context, 'login');
                  });
                  return AlertDialog(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    backgroundColor: purplelight,
                    content: const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$str_new_account_succes $str_welcome' ,textAlign: TextAlign.center ,
                          style: TextStyle(
                              color: whiteColor,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  );
                });
            await FlutterWindowManager.clearFlags(
                FlutterWindowManager.FLAG_NOT_TOUCHABLE);
            if (context.mounted) {
              Navigator.pushReplacementNamed(context, 'login');
            } else {
              print('Contexto no disponible - navegación cancelada');
            }
          }
          if (state.isFailure!) {
            if ('' == 'Permission Denied' && context.mounted) {
              showWarning(context);
              await Future.delayed(const Duration(seconds: 5));
              Navigator.of(context).pop();
              //AppSettings.openAppSettings();
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(
                  SnackBar(
                    content: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          state.error!,
                        ),
                        const Icon(Icons.error),
                      ],
                    ),
                    backgroundColor: Colors.red,
                  ),
                );
            } else {
              // FlutterWindowManager.clearFlags(
              //     FlutterWindowManager.FLAG_NOT_TOUCHABLE);
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(
                  SnackBar(
                    content: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          state.error!,
                        ),
                        const Icon(Icons.error),
                      ],
                    ),
                    backgroundColor: Colors.red,
                  ),
                );
            }
            await FlutterWindowManager.clearFlags(
                FlutterWindowManager.FLAG_NOT_TOUCHABLE);
          }
        },
        child: BlocBuilder(
            bloc: _registerBloc,
            builder: (BuildContext context, RegisterState state) {
              return Column(
                children: <Widget>[
                  formUI(state, context),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    child: CheckboxListTile(
                      value:
                          _isChecked, // Add a boolean variable to track the checkbox state
                      onChanged: (value) {
                        setState(() {
                          _isChecked = value!;
                          //_registerBloc.add(TermsAndConditiosnChange(isChecked: _isChecked));
                        });
                      },
                      title: const Text(
                        'Acepto los términos y condiciones',
                        style: TextStyle(color: secondary),
                      ),
                      controlAffinity: ListTileControlAffinity.leading,
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.all(25.0),
                    child: ElevatedButton(
                      onPressed: checkValidFields(state)
                          ? () {
                              _registerBloc.add(ButtonSubmitPressed(
                                  isFormValid: state.isFormValid));
                              if (isRegisterButtonEnabled(state)) {
                                _onFormSubmitted();
                              }
                            }
                          : null,
                      style: ElevatedButton.styleFrom(
                        disabledBackgroundColor:
                            const Color.fromARGB(103, 23, 57, 97),
                        backgroundColor: primaryColor,
                        foregroundColor: whiteColor,
                      ),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 16.0,
                            horizontal: 48.0), // Adjust the padding as needed
                        child: Text(str_create_account),
                      ),
                    ),
                  ),

                  //)
                ],
              );
            }),
      ),

      //)
      //state), );
    );
  }

  bool checkValidFields(RegisterState state) {
    if (_nameController.text.isNotEmpty &&
        _emailController.text.isNotEmpty &&
        _passwordController.text.isNotEmpty &&
        _confirmPasswordController.text.isNotEmpty &&
        state.isNameValid &&
        state.isEmailValid &&
        state.isPasswordValid &&
        state.isConfirmPasswordValid &&
        _isChecked) {
      return true;
    } else {
      return false;
    }
  }

  //bool _isChecked = false;
  Widget formUI(RegisterState state, BuildContext context) {
    //RegisterState state, BuildContext context) {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
        // decoration: BoxDecoration(
        //   borderRadius: BorderRadius.circular(10.0),
        //   color: Color.fromARGB(59, 245, 223, 20),
        // ),
        child: Column(children: <Widget>[
          _nameField(state),
          _mailField(state),
          _passwordField(state),
          _confirmPasswordField(state),
        ]));
  }

  Widget _nameField(RegisterState state) {
    return TextFieldWidget(
      controller: _nameController,
      icon: const Icon(
        Icons.person_rounded,
        color: secondary, // Color del icono
      ),
      hintText: str_name_last,
      isValid: state.isNameValid,
      errorMessage: 'Nombre no permitido',
    );
  }

  Widget _mailField(RegisterState state) {
    return TextFieldWidget(
      keyboardType: TextInputType.emailAddress,
      controller: _emailController,
      icon: const Icon(
        Icons.mail_rounded,
        color: secondary, // Color del icono
      ),
      hintText: str_mail,
      isValid: state.isEmailValid,
      errorMessage: str_valid_mail_invalid,
    );
  }

  // Widget _direccionField(RegisterState state) {
  //   return TextFieldWidget(
  //     controller: _direccionController,
  //     icon: const Icon(
  //       Icons.other_houses_rounded,
  //       color: secondary1,
  //       // Color del icono
  //     ),
  //     hintText: str_address,
  //     isValid: state.isDireccionValid,
  //     errorMessage: str_valid_address,
  //   );
  // }

  // Widget _phoneField(RegisterState state) {
  //   return TextFieldWidget(
  //     keyboardType: TextInputType.phone,
  //     controller: _telefonoController,
  //     icon: const Icon(
  //       Icons.phone_iphone_rounded,
  //       color: secondary1,
  //       // Color del icono
  //     ),
  //     hintText: str_phone,
  //     isValid: state.isPhoneValid,
  //     errorMessage: str_valid_phone_invalid,
  //   );
  // }

  Widget _passwordField(RegisterState state) {
    return PasswordTextFieldWidget(
        keyboardType: TextInputType.text,
        controller: _passwordController,
        icon: const Icon(
          Icons.password_rounded,
          color: secondary, // Color del icono

          // Color del icono
        ),
        hintText: "Contraseña",
        isValid: state.isPasswordValid,
        errorMessage: str_valid_min_characters,
        passwordVisible: passwordVisible!);
    // return Column(
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: <Widget>[
    //       Container(
    //         padding: const EdgeInsets.symmetric(horizontal: 16.0),
    //         margin: const EdgeInsets.symmetric(vertical: 1.0, horizontal: 5.00),
    //         decoration: BoxDecoration(
    //           color: Colors.grey[300], // Color de fondo gris
    //           borderRadius: BorderRadius.circular(10.0), // Bordes redondeados
    //         ),
    //         child: Row(
    //           children: <Widget>[
    //             const Icon(Icons.password_rounded, color: secondary1),
    //             const SizedBox(
    //                 width: 10.0), // Espacio entre el icono y el TextFormField
    //             Expanded(
    //               child: TextFormField(
    //                 keyboardType: TextInputType.visiblePassword,
    //                 controller: _passwordController,
    //                 decoration: InputDecoration(
    //                     hintText: 'Contraseña',
    //                     border: InputBorder
    //                         .none, // Sin borde alrededor del TextFormField
    //                     suffix: IconButton(
    //                         onPressed: () {
    //                           setState(() {
    //                             passwordVisible = !passwordVisible!;
    //                           });
    //                         },
    //                         icon: Icon(
    //                           passwordVisible!
    //                               ? Icons.visibility
    //                               : Icons.visibility_off,
    //                           color: secondary1,
    //                         ))),
    //                 autovalidateMode: AutovalidateMode.onUserInteraction,
    //                 validator: (_) {},
    //                 obscureText: passwordVisible!,
    //               ),
    //             ),
    //           ],
    //         ),
    //       ),
    //       if (!state
    //           .isPasswordValid) // Mostrar mensaje de error solo si no es válido y hay un mensaje de error
    //         const Padding(
    //           padding: EdgeInsets.only(left: 20.0, top: 1.0),
    //           child: Text(
    //             str_valid_characters,
    //             style: TextStyle(
    //               color: Colors.red,
    //               fontSize: 12.0,
    //             ),
    //           ),
    //         ),
    //     ]);
  }

  // Widget _confirmPasswordField(RegisterState state) {
  //   return Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: <Widget>[
  //         Container(
  //           padding: const EdgeInsets.symmetric(horizontal: 16.0),
  //           margin: const EdgeInsets.symmetric(horizontal: 5.00),
  //           decoration: BoxDecoration(
  //             color: Colors.grey[300], // Color de fondo gris
  //             borderRadius: BorderRadius.circular(10.0), // Bordes redondeados
  //           ),
  //           child: Row(
  //             children: <Widget>[
  //               const Icon(Icons.password_rounded, color: secondary1),
  //               const SizedBox(
  //                   width: 10.0), // Espacio entre el icono y el TextFormField
  //               Expanded(
  //                 child: TextFormField(
  //                   keyboardType: TextInputType.visiblePassword,
  //                   controller: _confirmPasswordController,
  //                   decoration: InputDecoration(
  //                       hintText: str_confirm_pwd,
  //                       border: InputBorder.none,
  //                       suffix: IconButton(
  //                           onPressed: () {
  //                             setState(() {
  //                               passwordVisibleConfir = !passwordVisibleConfir!;
  //                             });
  //                           },
  //                           icon: Icon(
  //                             passwordVisible!
  //                                 ? Icons.visibility
  //                                 : Icons.visibility_off,
  //                             color: secondary1,
  //                           ))),
  //                   autovalidateMode: AutovalidateMode.onUserInteraction,
  //                   validator: (_) {
  //                     return null;
  //                   },
  //                   obscureText: passwordVisibleConfir!,
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //         if (!state.isConfirmPasswordValid) // ||
  //           //Validators.isValidPasswordConfirmOldChangeValue(_passwordController.text, _confirmPasswordController.text)) // Mostrar mensaje de error solo si no es válido y hay un mensaje de error
  //           const Padding(
  //             padding: EdgeInsets.only(left: 20.0, top: 1.0),
  //             child: Text(
  //               str_valid_pwd, //str_valid_characters,
  //               style: TextStyle(
  //                 color: Colors.red,
  //                 fontSize: 12.0,
  //               ),
  //             ),
  //           )
  //         else if (!Validators.isValidPasswordConfirmOldChangeValue(
  //             _passwordController.text, _confirmPasswordController.text))
  //           const Padding(
  //             padding: EdgeInsets.only(left: 20.0, top: 1.0),
  //             child: Text(
  //               str_valid_pwd, //str_valid_characters,
  //               style: TextStyle(
  //                 color: Colors.red,
  //                 fontSize: 12.0,
  //               ),
  //             ),
  //           )
  //       ]);
  // }

  Widget _confirmPasswordField(RegisterState state) {
    return PasswordTextFieldWidget(
        keyboardType: TextInputType.text,
        controller: _confirmPasswordController,
        icon: const Icon(
          Icons.password_rounded,
          color: secondary, // Color del icono

          //color: secondary1,
          // Color del icono
        ),
        hintText: str_confirm_pwd,
        isValid: state.isConfirmPasswordValid,
        errorMessage: str_valid_pwd,
        passwordVisible: passwordVisible!);
  }

  String removerTildes(String cadena) {
    return cadena
        .replaceAll("Á", "A")
        .replaceAll("É", "E")
        .replaceAll("Í", "I")
        .replaceAll("Ó", "O")
        .replaceAll("Ú", "U")
        .replaceAll("á", "a")
        .replaceAll("é", "e")
        .replaceAll("í", "i")
        .replaceAll("ó", "o")
        .replaceAll("ú", "u");
  }
  // updateCedulaApiResult(int idT) async {
  //   String cedu = removerTildes(tipo!);
  //   _authProviderAlways ??= AuthProvider();
  //   await _authProviderAlways!.authenticate(_prefs.email, _prefs.secret!);

  //   await _authProviderAlways!.updateCedulaApi(
  //       idT, _prefs.cedula, cedu.trim().toLowerCase().toString());
  //   _authProviderAlways!.signOut();
  // }
  Future _onFormSubmitted() async {
    // final useroffline = UserOffline(
    //   login: _emailController.text,
    //   cedula: _cedulaController.text,
    //   name: _nameController.text.trim(),
    //   direccion: _direccionController.text.trim(),
    //   phone: _telefonoController.text,
    //   password: _passwordController.text,
    //   confirmPassword: _confirmPasswordController.text,
    // );

    final user = User(
      _emailController.text.trim(),
      _nameController.text,
      _passwordController.text.trim(),

      //_direccionController.text,
      //_telefonoController.text,
      // _passwordController.text,
      //_confirmPasswordController.text
    );

    _registerBloc.add(Submitted(user: user));
  }

//   Widget _passwordField(RegisterState state) {
//     return TextFieldWidget(
//       keyboardType: TextInputType.visiblePassword,
//       controller: _passwordController,
//       icon: Icon(
//         Icons.password_rounded,
//         color: secondary1,
//         // Color del icono
//       ),
//       hintText: 'Contraseña',
//       isValid: state.isPasswordValid,
//       errorMessage: str_valid_characters,
//     );
//   }

//   Widget _confirmPasswordField(RegisterState state) {
//     return TextFieldWidget(
//       keyboardType: TextInputType.visiblePassword,
//       controller: _confirmPasswordController,
//       icon: Icon(
//         Icons.password_rounded,
//         color: secondary1,
//         // Color del icono
//       ),
//       hintText: str_confirm_pwd,
//       isValid: _confirmPassword(state),
//       errorMessage: str_valid_pwd,
//     );
//   }

// bool _confirmPassword(RegisterState state){
//   if (state.isConfirmPasswordValid &&  !Validators.isValidPasswordConfirmOldChangeValue(
//                     _passwordController.text, _passwordController.text,) ) {
//     return true;
//   }else{
//     return false;
//   }

// }
  // Widget _checkBoxTermsAndConditionsField(RegisterState state){
  //   return Checkbox(
  //                 value: _isChecked,
  //                 onChanged: (value) {
  //                   setState(() {
  //                     _isChecked = value;
  //                   });
  //                 },
  //               ),
  //               Text('Acepto los términos y condiciones')
  // }

  void _onCedulaChanged() {
    //if (_cedulaController.text.length < 10) {
    _registerBloc.add(
      CedulaChanged(cedula: _cedulaController.text, passport: ""),
    );
    // } else {
    //   _registerBloc.add(
    //     CedulaChanged(cedula: "", passport: _cedulaController.text),
    //   );
    // }
  }

  void _onEmailChanged() {
    _registerBloc.add(
      EmailChanged(email: _emailController.text),
    );
  }

  void _onNameChanged() {
    _registerBloc.add(
      NameChanged(name: _nameController.text),
    );
  }

  void _onDireccionChanged() {
    _registerBloc.add(
      DireccionChanged(direccion: _direccionController.text),
    );
  }

  void _onPhoneChanged() {
    _registerBloc.add(
      PhoneChanged(phone: _telefonoController.text),
    );
  }

  void _onPasswordChanged() {
    _registerBloc.add(
      PasswordChanged(password: _passwordController.text),
    );
  }

  void _onConfirmPasswordChanged() {
    _registerBloc.add(
      ConfirmPasswordChanged(
          password: _passwordController.text,
          confirmPassword: _confirmPasswordController.text),
    );
  }
}
