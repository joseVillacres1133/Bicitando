import 'package:flutter/material.dart';

import '../data/auth_provider.dart';
import '../style/style.dart';

class Terms extends StatefulWidget {
  @override
  _TermsState createState() => _TermsState();
}

class _TermsState extends State<Terms> {
  late AuthProvider authProvider;

  @override
  void initState() {
    super.initState();
    authProvider = AuthProvider();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: loadTerms(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator(
              color: secondary,
            );
          } else if (snapshot.hasData == false) {
            return Container(
              //color: whiteColor,
              child:
                  const Center(child: Text('No existe términos y condiciones')),
            );
          } else {

            return Flexible(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(
                      20.0), // Ajusta el padding según sea necesario
                  child: Text(
                    snapshot.data[0]!,
                    style: const TextStyle(
                      
                      fontSize: 14.0,
                      fontStyle: FontStyle.italic, // Aplica el estilo cursivo
                    ),
                  ),
                ),
              ),
            );
          }
        });
  }

  List<String> terms = [];
  Future<dynamic> loadTerms() async {
    var response = await authProvider.getTerms();
    if (response.isNotEmpty) {
      terms = response;
      return terms;
    } else {
      return terms.add('Error');
    }
  }
}
