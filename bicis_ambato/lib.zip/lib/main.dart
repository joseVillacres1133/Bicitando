import 'dart:convert';
import 'dart:developer';

import 'package:bicis_ambato/blocs/app/bloc.dart';
import 'package:bicis_ambato/blocs/app/theme/theme_cubit.dart';
import 'package:bicis_ambato/config/theme/app_theme.dart';
import 'package:bicis_ambato/views/document_indications_screen.dart';
import 'package:bicis_ambato/views/help_screen.dart';
import 'package:bicis_ambato/views/history_screen.dart';
import 'package:bicis_ambato/views/terms_conditions_screen.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as loc;
import 'package:odoo_rpc/odoo_rpc.dart';
import 'package:permission_handler/permission_handler.dart';

import 'blocs/auth/auth_bloc.dart';
import 'blocs/auth/auth_event.dart';
import 'blocs/auth/auth_state.dart';
import 'data/auth_provider.dart';
import 'data/repository.dart';
import 'utils/constants_msg.dart';
import 'utils/sharedprefs_helper.dart';
import 'views/change_password_screen.dart';
import 'views/edit_profile_screen.dart';
import 'views/forgot_password.screen.dart';
import 'views/login_screen.dart';
import 'views/profile_screen.dart';
import 'views/register_screen.dart';
import 'views/home_screen.dart';
import 'views/splash_screen.dart';
import 'widget/auth/resetPassword_form.dart';

//import 'views/auth/login_screen.dart';

void main() async {
  final cameras = await availableCameras();
  final prefs = Prefs();
  await prefs.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {

  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) => ThemeCubit(), // Crea un ThemeCubit
        child: const MaterialApp(
          home: SplashScreen(),
        ) // Usa AppRoot en lugar de MaterialApp directamente
        );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> with WidgetsBindingObserver {
  Prefs? _prefs; //Instanciamos los sharedPreferences que vamos a utilizar
  final Repository _repository =
      Repository(odooClient: OdooClient("https://its.mivilsoft.com"));
  AuthProvider? _repositoryAuth;
  AuthBloc? _authBloc;

  Uint8List? _bytesImage;

  loc.Location location = loc.Location();
  loc.LocationData? _locationData;

  final GlobalKey<NavigatorState>? navigatorkey = GlobalKey<NavigatorState>();

  //late ThemeCubit themeCubit;
  late AppTheme appTheme;

  @override
  void initState() {
    super.initState();
    _repositoryAuth = AuthProvider();
    _prefs = Prefs();
    getPermissionLocation();
    _authBloc = AuthBloc(
        repository: _repository,
        authProvider: _repositoryAuth!,
        context: context);
    _authBloc!.add(AppStarted());
    //themeCubit = ThemeCubit();
    appTheme = AppTheme(isDarkmode: _prefs!.isDarkThemeEnabled);
  }

  Future<Uint8List> cargarImagen(String ruta) async {
    ByteData data = await rootBundle.load(ruta);
    return data.buffer.asUint8List();
  }

  updateImage() async {
    if (_prefs!.requireUserPhoto != str_false) {
      String imgOcupar = _prefs!.requireUserPhoto.toString();
      _bytesImage = const Base64Decoder().convert(imgOcupar);
    } else {
      _bytesImage = await cargarImagen('assets/user.png');
    }
  }

  void getLocation() async {
    Position position = await Geolocator.getCurrentPosition();
    _prefs!.latitud = position.latitude.toString();
    _prefs!.longitud = position.longitude.toString();
    Coordinates coordinates =
        Coordinates(position.latitude, position.longitude);
    var address =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    _prefs!.cityOrigen = address.first.locality!;
  }

  getPermissionLocation() async {
    //if (!_serviceEnabled) return;
    PermissionStatus statusLocation = await Permission.location.status;
    PermissionStatus statusCamera = await Permission.location.status;

    if (statusLocation.isDenied) {
      // Si los permisos están denegados, solicítalos
      statusLocation = await Permission.location.request();
    }
    if (statusCamera.isDenied) {
      statusCamera = await Permission.camera.request();
    }

    getLocation();
    _getCurrentLocation();
    _locationData = await location.getLocation();
    _prefs!.latitud = _locationData!.latitude.toString();
    _prefs!.longitud = _locationData!.longitude.toString();
  }

  Future<void> _getCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition()
          .timeout(const Duration(seconds: 5));

      if (position != null) {
        Coordinates coordinates =
            Coordinates(position.latitude, position.longitude);

        var address =
            await Geocoder.local.findAddressesFromCoordinates(coordinates);

        setState(() {
          _prefs!.latitud = position.latitude.toString();
          _prefs!.longitud = position.longitude.toString();
          _prefs!.cityOrigen = address.first.locality!;
        });
      } else {
        setState(() {
          //_prefs.latitud = "0.0";
          //_prefs.longitud = "0.0";
        });
      }
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    //return ScreenUtilInit();

    final themeCubit = context.watch<ThemeCubit>();
    themeCubit.emit(_prefs!.isDarkThemeEnabled);
    return MultiBlocProvider(
        providers: [
          BlocProvider(create: (context) => _authBloc!),
        ],
        child: MaterialApp(
          title: 'Ambato en bici',
          navigatorKey: navigatorkey,
          theme: appTheme.getThemeData(themeCubit.state),
          routes: <String, WidgetBuilder>{
            'login': (BuildContext context) =>
                LoginScreen(repository: _repository, context: context),
            'history': (BuildContext context) =>
                HistoryScreen(repository: _repository, context: context),
            'terms': (BuildContext context) => TermsConditionsScreen(
                repository: _repository, context: context),
            'help': (BuildContext context) =>
                HelpScreen(repository: _repository, context: context),
            'home': (BuildContext context) => HomeScreen(
                functionUpdate: updateImage,
                repository: _repository,
                longitud: _prefs!.longitud != null
                    ? double.parse(_prefs!.longitud)
                    : 0.0,
                latitud: _prefs!.latitud != null
                    ? double.parse(_prefs!.latitud)
                    : 0.0),
            'register': (BuildContext context) =>
                RegisterScreen(repository: _repository),
            'resetPass': (BuildContext context) => ResetPasswordForm(
                  email: _prefs!.email, //?? "",
                  oldPass: _prefs!.secret, // ?? "",
                ),
            'sentReset': (BuildContext context) =>
                ForgotPasswordScreen(repository: _repository, context: context),
            'profile': (BuildContext context) => ProfileScreen(
                repository: _repositoryAuth, bytesImage: _bytesImage),
            'edit-profile': (BuildContext context) => EditProfileScreen(
                repository: _repositoryAuth,
                context: context,
                bytesImage: _bytesImage),
            'change-psswd': (BuildContext context) =>
                const ChangePasswordScreen(),
            'upload-file': (BuildContext context) =>
                DocumentIndicationsScreen( repository: _repositoryAuth, )
          },
          home: BlocBuilder(
              bloc: _authBloc,
              builder: (BuildContext context, AuthState state) {
                if (state is Authenticated) {
                  return HomeScreen(
                      repository: _repository,
                      latitud: _prefs!.latitud != null
                          ? double.parse(_prefs!.latitud)
                          : 0.0,
                      longitud: _prefs!.longitud != null
                          ? double.parse(_prefs!.longitud)
                          : 0.0);
                }
                if (state is Unauthenticated) {
                  return LoginScreen(repository: _repository, context: context);
                } else {
                  return RegisterScreen(repository: _repository);
                }
              }),
        ));
  }
}
