// ignore_for_file: unused_import

import 'dart:typed_data';

import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'constants.dart';

//Configuracion de los SharedPreferences
class Prefs {
  static final Prefs _instance = Prefs._internal();
  Prefs._internal();
  factory Prefs() {
    return _instance;
  }

  late SharedPreferences _prefs;

  init() async {
    WidgetsFlutterBinding.ensureInitialized();
    _prefs = await SharedPreferences.getInstance(); //Instanciando
  }

  clear() {
    _prefs.clear();
  }

  bool get requireAuthentication =>
      _prefs.getBool(kSharedPrefRequireAuthentication) ?? true;
  set requireAuthentication(bool value) =>
      _prefs.setBool(kSharedPrefRequireAuthentication, value);

  bool get isUser =>
      _prefs.getBool(kSharedPrefIsUser) ?? true;
  set isUser(bool value) =>
      _prefs.setBool(kSharedPrefIsUser, value);

//Uint8List

  String get verifiedUser =>
      _prefs.getString(kSharedPrefVerifiedUser) ?? "none";
  set verifiedUser(String? value) =>
      _prefs.setString(kSharedPrefVerifiedUser, value!);
  String get requireUserPhoto =>
      _prefs.getString(kSharedPrefRequireUserPhoto) ?? "false";
  set requireUserPhoto(String? value) =>
      _prefs.setString(kSharedPrefRequireUserPhoto, value!);

  String get requireUserPhotoUrl =>
      _prefs.getString(kSharedPrefRequireUserPhotoUrl)!;
  set requireUserPhotoUrl(String? value) =>
      _prefs.setString(kSharedPrefRequireUserPhotoUrl, value!);

  bool get requireOffline => _prefs.getBool(kSharedPrefOffline) ?? false;
  set requireOffline(bool value) => _prefs.setBool(kSharedPrefOffline, value);

  bool get requireGPS => _prefs.getBool(kSharedPrefGPS) ?? false;
  set requireGPS(bool value) => _prefs.setBool(kSharedPrefGPS, value);

  int get idUser => _prefs.getInt(kSharedPrefIdUser)!;
  set idUser(int? value) => _prefs.setInt(kSharedPrefIdUser, value!);

  int get tiempoSeconds => _prefs.getInt(kSharedPrefTimeSecond)!;
  set tiempoSeconds(int value) => _prefs.setInt(kSharedPrefTimeSecond, value);

  int get idTo => _prefs.getInt(kSharedPrefIdTo)!;
  set idTo(int value) => _prefs.setInt(kSharedPrefIdTo, value);

  int get idFrom => _prefs.getInt(kSharedPrefIdFrom)!;
  set idFrom(int value) => _prefs.setInt(kSharedPrefIdFrom, value);

  int get idStatus => _prefs.getInt(kSharedPrefIdStatus)!;
  set idStatus(int value) => _prefs.setInt(kSharedPrefIdStatus, value);

  // String get mapboxUrl =>
  //     _prefs.getString(kSharedPrefmapboxUrl) ??
  //     "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  // set mapboxUrl(String value) => _prefs.setString(kSharedPrefmapboxUrl, value);

  String get userName => _prefs.getString(kSharedPrefName)!;
  set userName(String value) => _prefs.setString(kSharedPrefName, value);

  String get servicState => _prefs.getString(kSharedPrefEstadoServicio)!;
  set servicState(String value) =>
      _prefs.setString(kSharedPrefEstadoServicio, value);

  String get cityOrigen => _prefs.getString(kSharedPrefcityOrigen)!;
  set cityOrigen(String value) =>
      _prefs.setString(kSharedPrefcityOrigen, value);
  String get cityCompany => _prefs.getString(kSharedPrefcityCompany)!;
  set cityCompany(String value) =>
      _prefs.setString(kSharedPrefcityCompany, value);

  int get idUserPartner => _prefs.getInt(kSharedPrefIdUserPartner)!;
  set idUserPartner(int value) =>
      _prefs.setInt(kSharedPrefIdUserPartner, value);

  int get idPickCon => _prefs.getInt(kSharedPrefIdPickCon)!;
  set idPickCon(int value) => _prefs.setInt(kSharedPrefIdPickCon, value);

  String get origen => _prefs.getString(KSharedPrefOrigen)!;
  set origen(String value) => _prefs.setString(KSharedPrefOrigen, value);

  String get destino => _prefs.getString(KSharedPrefDestino) ?? "";
  set destino(String value) => _prefs.setString(KSharedPrefDestino, value);

  String get latitud => _prefs.getString(KSharedPrefLatitud) ?? "-1.2490800";
  set latitud(String value) => _prefs.setString(KSharedPrefLatitud, value);

  String get longitud => _prefs.getString(KSharedPrefLongitud) ?? "-78.6167500";
  set longitud(String value) => _prefs.setString(KSharedPrefLongitud, value);

  String get latitudOrigen => _prefs.getString(KSharedPrefLatitudOrigen)!;
  set latitudOrigen(String value) =>
      _prefs.setString(KSharedPrefLatitudOrigen, value);

  String get longitudOrigen => _prefs.getString(KSharedPrefLongitudOrigen)!;
  set longitudOrigen(String value) =>
      _prefs.setString(KSharedPrefLongitudOrigen, value);

  String get sessionId => _prefs.getString(kKeychainSessionId)!;
  set sessionId(String value) => _prefs.setString(kKeychainSessionId, value);

  bool get resetPass => _prefs.getBool(KSharedPrefResetPass) ?? false;
  set resetPass(bool value) => _prefs.setBool(KSharedPrefResetPass, value);

  String get cedula => _prefs.getString(kSharedPrefCedula)!;
  set cedula(String value) => _prefs.setString(kSharedPrefCedula, value);

  String get direccion => _prefs.getString(kSharedPrefDireccion)!;
  set direccion(String value) => _prefs.setString(kSharedPrefDireccion, value);

  String get telefono => _prefs.getString(kSharedPrefTelefono)!;
  set telefono(String value) => _prefs.setString(kSharedPrefTelefono, value);

  String get email => _prefs.getString(kKeychainEmail)!;
  set email(String value) => _prefs.setString(kKeychainEmail, value);

  String? get secret => _prefs.getString(kKeychainSecret);
  set secret(String? value) => _prefs.setString(kKeychainSecret, value!);

  String? get lastLogin => _prefs.getString(kKeychainLastLogin);
  set lastLogin(String? value) => _prefs.setString(kKeychainLastLogin, value!);

  bool get isDarkThemeEnabled =>
      _prefs.getBool(kSharedPrefIsDarkThemeEnabled) ?? false;
  set isDarkThemeEnabled(bool value) =>
      _prefs.setBool(kSharedPrefIsDarkThemeEnabled, value);

  String get changePassword => _prefs.getString(kKeychangePassword) ?? "false";
  set changePassword(String value) =>
      _prefs.setString(kKeychangePassword, value);

  bool get accountValidate =>
      _prefs.getBool(KSharedPrefValidateAccount) ?? false;
  set accountValidate(bool value) =>
      _prefs.setBool(KSharedPrefValidateAccount, value);

  // String get country => _prefs.getString(KSharedCountry) ?? "EC";
  // set country(String value) => _prefs.setString(KSharedCountry, value);

  bool get activeService => _prefs.getBool(kSharedActiveService) ?? false;
  set activeService(bool value) => _prefs.setBool(kSharedActiveService, value);

  String get distanceMeters => _prefs.getString(kSharedPrefIPTraccar) ?? "10.0";
  set distanceMeters(String value) =>
      _prefs.setString(kSharedPrefIPTraccar, value);
}
