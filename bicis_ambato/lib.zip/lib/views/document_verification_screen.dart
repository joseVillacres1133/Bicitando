// import 'package:flutter/material.dart';
// import 'package:share_whatsapp/share_whatsapp.dart';

// class DocumentVerificationScreen extends StatefulWidget {
//     final XFile frontImage;
//   final XFile backImage;

//     const DocumentVerificationScreen({
//     Key? key,
//     required this.frontImage,
//     required this.backImage,
//   }) : super(key: key);

//     @override
//   Widget build(BuildContext context) {
//     return ;
//   }
  
//   @override
//   State<StatefulWidget> createState() {
//     // TODO: implement createState
//     return Scaffold();
//   }
// }