import 'package:bicis_ambato/main.dart';
import 'package:bicis_ambato/style/style.dart';
import 'package:bicis_ambato/utils/constants_msg.dart';
import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splash: Image.asset(img_logo), // Imagen de Splash

      splashTransition: SplashTransition.fadeTransition, // Tipo de transición
      pageTransitionType: PageTransitionType
          .rightToLeftWithFade, // Tipo de transición de la página siguiente
      nextScreen: const MainPage(), // Pantalla siguiente después del Splash
      duration: 500, // Duración en milisegundos
      backgroundColor: whiteColor, // Color de fondo
    );
  }
}
